import xbmc
import xbmcaddon
import requests
import json
import datetime
import pymysql

class ScrobblerMonitor(xbmc.Monitor):
    def __init__(self, player):
        super().__init__()
        self.player = player

    def onSettingsChanged(self):
        xbmc.log("MariaDB Scrobbler: Settings changed. Reloading connection...", xbmc.LOGINFO)
        self.player.load_settings()

class ScrobblePlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.session_id = None
        self.current_time = 0
        self.total_time = 0
        self.db = None
        self.cursor = None
        self.tmdb_api_key = ""
        self.load_settings()
        
    def load_settings(self):
        addon = xbmcaddon.Addon()
        self.tmdb_api_key = addon.getSetting('tmdb_api_key')
        
        host = addon.getSetting('db_host')
        port_str = addon.getSetting('db_port')
        port = int(port_str) if port_str.isdigit() else 3306
        user = addon.getSetting('db_user')
        password = addon.getSetting('db_pass')
        database = addon.getSetting('db_name')
        
        if self.db:
            try:
                self.db.close()
            except:
                pass
                
        try:
            self.db = pymysql.connect(
                host=host, port=port, user=user, password=password, database=database, charset='utf8mb4'
            )
            self.cursor = self.db.cursor()
            xbmc.log("MariaDB Scrobbler: Connected to DB successfully", xbmc.LOGINFO)
        except Exception as e:
            self.db = None
            xbmc.log(f"MariaDB Scrobbler DB Error: {e}", xbmc.LOGERROR)

    def fetch_tmdb_details(self, media_type, tmdb_id):
        if not self.tmdb_api_key:
            return {}
            
        tmdb_type = 'tv' if media_type == 'episode' else 'movie'
        url = f"https://api.themoviedb.org/3/{tmdb_type}/{tmdb_id}?api_key={self.tmdb_api_key}"
        try:
            return requests.get(url).json()
        except Exception as e:
            xbmc.log(f"TMDB Fetch Error: {e}", xbmc.LOGERROR)
            return {}

    def mark_kodi_watched(self, media_type):
        """Forces Kodi to mark item watched if it exists in the local library DB."""
        dbid = xbmc.getInfoLabel('VideoPlayer.DBID')
        if not dbid or not dbid.isdigit():
            return  # Skip safely if playing from a streaming plugin without a local DBID
            
        try:
            if media_type == 'episode':
                method = 'VideoLibrary.SetEpisodeDetails'
                params = {'episodeid': int(dbid), 'playcount': 1}
            elif media_type == 'movie':
                method = 'VideoLibrary.SetMovieDetails'
                params = {'movieid': int(dbid), 'playcount': 1}
            else:
                return

            rpc_cmd = {
                "jsonrpc": "2.0",
                "method": method,
                "params": params,
                "id": 1
            }
            xbmc.executeJSONRPC(json.dumps(rpc_cmd))
            xbmc.log(f"MariaDB Scrobbler: Marked {media_type} {dbid} as watched in Kodi UI", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"MariaDB Scrobbler: Failed to mark watched in Kodi UI: {e}", xbmc.LOGERROR)

    def set_kodi_resume_point(self, media_type, current_time, total_time):
        """Forces Kodi to update resume point if it exists in the local library DB."""
        dbid = xbmc.getInfoLabel('VideoPlayer.DBID')
        if not dbid or not dbid.isdigit():
            return  # Skip safely if playing from a streaming plugin without a local DBID
            
        try:
            if media_type == 'episode':
                method = 'VideoLibrary.SetEpisodeDetails'
                params = {'episodeid': int(dbid), 'resume': {'position': current_time, 'total': total_time}}
            elif media_type == 'movie':
                method = 'VideoLibrary.SetMovieDetails'
                params = {'movieid': int(dbid), 'resume': {'position': current_time, 'total': total_time}}
            else:
                return

            rpc_cmd = {
                "jsonrpc": "2.0",
                "method": method,
                "params": params,
                "id": 1
            }
            xbmc.executeJSONRPC(json.dumps(rpc_cmd))
            xbmc.log(f"MariaDB Scrobbler: Set resume point in Kodi UI at {current_time}s", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"MariaDB Scrobbler: Failed to set resume point in Kodi UI: {e}", xbmc.LOGERROR)

    def onAVStarted(self):
        if not self.isPlayingVideo() or not self.db:
            return
            
        xbmc.sleep(1000)
        
        title = xbmc.getInfoLabel('VideoPlayer.Title')
        tmdb_id = xbmc.getInfoLabel('VideoPlayer.IMDBNumber')
        current_profile = xbmc.getInfoLabel('System.ProfileName')
        
        # Capture Season and Episode numbers
        season_raw = xbmc.getInfoLabel('VideoPlayer.Season')
        episode_raw = xbmc.getInfoLabel('VideoPlayer.Episode')
        season_num = int(season_raw) if season_raw and season_raw.isdigit() else None
        episode_num = int(episode_raw) if episode_raw and episode_raw.isdigit() else None
        
        # Determine media type dynamically based on whether season/episode data exists
        media_type = 'episode' if (season_num is not None or episode_num is not None) else 'movie'
        
        if not tmdb_id:
            return 
            
        tmdb_data = self.fetch_tmdb_details(media_type, tmdb_id)
        
        try:
            self.db.ping(reconnect=True)
            self.cursor = self.db.cursor()

            self.cursor.execute("""
                SELECT progress_sec 
                FROM scrobbles 
                WHERE tmdb_id = %s and profile_name = %s and is_finished = 0 
                ORDER BY start_time DESC LIMIT 1
            """, (tmdb_id, current_profile))
            
            result = self.cursor.fetchone()
            if result and result[0] > 0:
                self.seekTime(result[0])
                
            now = datetime.datetime.now()
            
            self.cursor.execute("""
                INSERT INTO scrobbles (tmdb_id, media_type, title, season_num, episode_num, start_time, profile_name)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (tmdb_id, media_type, title, season_num, episode_num, now, current_profile))
            
            self.db.commit()
            self.session_id = self.cursor.lastrowid
        except Exception as e:
            xbmc.log(f"MariaDB Scrobbler Insert Error: {e}", xbmc.LOGERROR)
            return
            
        self._track_time(media_type)
        
    def _track_time(self, media_type):
        while self.isPlaying():
            try:
                self.current_time = self.getTime()
                self.total_time = self.getTotalTime()
                
                if self.session_id and self.db:
                    self.db.ping(reconnect=True)
                    self.cursor.execute("""
                        UPDATE scrobbles 
                        SET progress_sec = %s, total_sec = %s
                        WHERE id = %s
                    """, (self.current_time, self.total_time, self.session_id))
                    self.db.commit()
            except:
                pass
            xbmc.sleep(1000)
            
    def onPlayBackStopped(self):
        if not self.session_id or not self.db:
            return
            
        now = datetime.datetime.now()
        media_type = xbmc.getInfoLabel('VideoPlayer.DBTYPE')
        is_finished = 1 if (self.total_time > 0 and (self.current_time / self.total_time) >= 0.90) else 0
        
        if is_finished == 1:
            self.mark_kodi_watched(media_type)
        elif self.current_time > 0 and self.total_time > 0:
            self.set_kodi_resume_point(media_type, self.current_time, self.total_time)
            
        try:
            self.db.ping(reconnect=True)
            self.cursor = self.db.cursor()

            self.cursor.execute("""
                UPDATE scrobbles 
                SET progress_sec = %s, total_sec = %s, is_finished = %s, finish_time = %s
                WHERE id = %s
            """, (self.current_time, self.total_time, is_finished, now, self.session_id))
            self.db.commit()
        except Exception as e:
            xbmc.log(f"MariaDB Scrobbler Update Error: {e}", xbmc.LOGERROR)
            
        self.session_id = None

    def onPlayBackEnded(self):
        if not self.session_id or not self.db:
            return
            
        now = datetime.datetime.now()
        media_type = xbmc.getInfoLabel('VideoPlayer.DBTYPE')
        
        self.mark_kodi_watched(media_type)
        
        try:
            self.db.ping(reconnect=True)
            self.cursor = self.db.cursor()

            self.cursor.execute("""
                UPDATE scrobbles 
                SET is_finished = 1, finish_time = %s, progress_sec = total_sec
                WHERE id = %s
            """, (now, self.session_id))
            self.db.commit()
        except Exception as e:
             xbmc.log(f"MariaDB Scrobbler End Error: {e}", xbmc.LOGERROR)
             
        self.session_id = None

if __name__ == '__main__':
    player = ScrobblePlayer()
    monitor = ScrobblerMonitor(player)
    
    xbmc.log("MariaDB Scrobbler Started", xbmc.LOGINFO)
    
    while not monitor.abortRequested():
        monitor.waitForAbort(10)
    
    if player.db:
        player.db.close()