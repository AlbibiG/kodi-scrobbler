import xbmcaddon

# Instantly opens the settings GUI when you click the addon
xbmcaddon.Addon().openSettings()